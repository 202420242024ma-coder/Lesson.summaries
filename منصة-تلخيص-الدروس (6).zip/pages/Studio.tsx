import React from 'react';

const Studio = () => {
  return (
    <div className="p-8 text-center">
      <h2 className="text-2xl font-bold text-gray-500">Feature Removed</h2>
    </div>
  );
};

export default Studio;