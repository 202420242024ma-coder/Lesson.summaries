// This file is deprecated. 
// Logic has been moved to src/services/geminiService.ts to run client-side 
// using the Google Gen AI SDK directly.
export default function handler(req, res) {
  res.status(410).json({ error: "API route deprecated. Use client-side service." });
}